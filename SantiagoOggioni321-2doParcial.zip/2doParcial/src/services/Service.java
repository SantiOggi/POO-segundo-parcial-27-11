package services;

import java.util.List;

public interface Service<T> {

    default void harcodearEmpleados(List<? super T> lista) {
        //lista.add(new T);
        //lista.add();
      
    }

    default void listarEmpleados(List<? super T> lista) {
        lista.forEach(System.out::println);

    }
}
