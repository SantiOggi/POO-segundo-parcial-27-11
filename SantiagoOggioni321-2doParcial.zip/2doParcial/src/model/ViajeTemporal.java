package model;

import java.util.Objects;

public class ViajeTemporal implements Comparable<ViajeTemporal>, CSVSerializable {

    private int id;
    private String descripcion;
    private String viajero;
    private DestinoTemporal destino;

    public ViajeTemporal(int id, String descripcion, String viajero, DestinoTemporal destino) {
        this.id = id;
        this.descripcion = descripcion;
        this.viajero = viajero;
        this.destino = destino;
    }

    @Override
    public String toString() {
        return "ViajeTemporal{" + "id=" + id + ", descripcion=" + descripcion + ", viajero=" + viajero + ", destino=" + destino + '}';
    }

    @Override
    public int compareTo(ViajeTemporal otro) {
        return Integer.compare(id, otro.id);
    }

    @Override
    public String toHeaderCSV() {
        return "id,descripcion,viajero,destino";
    }

    @Override
    public String toCSV() {
        return id + "," + descripcion + "," + viajero + "," + destino;
    }

    public static ViajeTemporal fromCSV(String viajeCSV) {
        viajeCSV = viajeCSV.substring(0, viajeCSV.length());
        String[] datos = viajeCSV.split(",");
        return new ViajeTemporal(Integer.parseInt(datos[0]), datos[1], datos[2], DestinoTemporal.valueOf(datos[3]));
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof ViajeTemporal vt)) {
            return false;
        }
        return this.id == vt.id;
    }

    public int getId() {
        return id;
    }
    
    public boolean esDestino(DestinoTemporal destino){
        return this.destino == destino;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getViajero() {
        return viajero;
    }

    public DestinoTemporal getDestino() {
        return destino;
    }
    

}
