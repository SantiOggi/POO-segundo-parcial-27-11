package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Function;

public class LibroDeViajes<T extends CSVSerializable> implements Iterable<T>, Serializable {

    private List<T> viajes = new ArrayList<>();

    public void agregar(T item) {
        Objects.requireNonNull(item, "Intenta agregar un nulo al Libro.");
        viajes.add(item);
    }

    public boolean eliminar(T item) {
        return viajes.remove(item);
    }

    public T eliminar(int indice) {
        validarIndice(indice);
        return viajes.remove(indice);
    }

    public int tamanio() {
        return viajes.size();
    }

    private void validarIndice(int indice) {
        if (indice >= tamanio() || indice < 0) {
            throw new IndexOutOfBoundsException("El índice ingresado está fuera de la lista.");
        }
    }

    public T obtener(int indice) {
        validarIndice(indice);
        return viajes.get(indice);
    }

    @Override
    public Iterator<T> iterator() {
        return iterator((Comparator<T>) Comparator.naturalOrder());
    }

    public Iterator<T> iterator(Comparator<? super T> comp) {
        List<T> toReturn = new ArrayList<>(viajes);

        if (!estaVacio() && viajes.getFirst() instanceof Comparable) {
            toReturn.sort(comp);
        }

        return toReturn.iterator();
    }

    public boolean estaVacio() {
        return viajes.isEmpty();
    }

    public void paraCadaElemento(Consumer<? super T> accion) {
        viajes.forEach(accion);
    }

    public List<T> filtrar(Predicate<T> filtro) {
        List<T> toReturn = new ArrayList<>();
        for (T t : viajes) {
            if (filtro.test(t)) {
                toReturn.add(t);
            }
        }
        return toReturn;
    }

    public void ordenar(Comparator<T> criterio) {
        viajes.sort(criterio);

    }

    public void guardarEnCSV(String path) throws IOException {
        BufferedWriter escritor = new BufferedWriter(new FileWriter(path));
        if (!estaVacio()) {
            escritor.write(viajes.getFirst().toHeaderCSV() + "\n");
        }
        for (T v : viajes) {
            escritor.write(v.toCSV() + "\n");
        }
        escritor.close();

    }

    public LibroDeViajes<T> cargarDesdeCSV(String path, Function<String, T> func) throws FileNotFoundException, IOException {
        LibroDeViajes<T> toReturn = new LibroDeViajes();

        BufferedReader lector = new BufferedReader(new FileReader(path));
        String linea;
        lector.readLine();
        while ((linea = lector.readLine()) != null) {
            toReturn.agregar(func.apply(linea));
        }

        return toReturn;
    }

    public void guardarEnArchivo(String path) throws FileNotFoundException, IOException {
        ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(path));

        serializador.writeObject(viajes);
        
        serializador.close();

    }

    public void cargarDesdeArchivo(String path) throws FileNotFoundException, IOException, ClassNotFoundException {

        ObjectInputStream deser = new ObjectInputStream(new FileInputStream(path));
        this.viajes = (List<T>) deser.readObject();

    }
}
